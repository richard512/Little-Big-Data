#!/bin/bash

keyword=$1

if [ ! $keyword ]; then
	echo ""
	echo "Usage: $0 <keyword>"
	echo ""
	exit
fi

grep "$keyword" top-1m.csv > domtops/$keyword.csv
cat domtops/$keyword.csv | more
